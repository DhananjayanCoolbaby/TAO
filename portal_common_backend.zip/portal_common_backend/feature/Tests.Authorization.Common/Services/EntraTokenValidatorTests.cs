﻿using AA.PS.FS.Platform.Portal.Utilities.Authorization.Common.Services;
using FakeItEasy;
using FluentAssertions;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Protocols;
using Xunit;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Cryptography.X509Certificates;

namespace Test.Authorization.Common.Services
{
    public class EntraTokenValidatorTests
    {
        
        [Fact(Skip = "Requires real OpenID endpoint or code modification to mock config manager")]
        public async Task ValidateTokenAsync_WithInvalidToken_ReturnsFalse()
        {
            // Skipped due to external dependency.
        }
    }
}

    
