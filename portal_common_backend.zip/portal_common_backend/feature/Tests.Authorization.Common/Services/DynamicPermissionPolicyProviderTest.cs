﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Services;
using AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Handlers;
using FakeItEasy;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;

namespace Test.Authorization.Common.Services
{
    public class DynamicPermissionPolicyProviderTest
    {
        
            private readonly IOptions<AuthorizationOptions> _fakeOptions;
            private readonly DynamicPermissionPolicyProvider _policyProvider;

            public DynamicPermissionPolicyProviderTest()
            {
                _fakeOptions = A.Fake<IOptions<AuthorizationOptions>>();
                A.CallTo(() => _fakeOptions.Value).Returns(new AuthorizationOptions());

                _policyProvider = new DynamicPermissionPolicyProvider(_fakeOptions);
            }

            [Fact]
            public async Task GetPolicyAsync_WithDynamicPolicyName_ReturnsCustomPolicy()
            {
                // Arrange
                var policyName = "PermissionPolicy:Read,Write";

                // Act
                var policy = await _policyProvider.GetPolicyAsync(policyName);

                // Assert
                Assert.NotNull(policy);
                Assert.Contains(policy.Requirements, r => r is PermissionRequirement);
            }

            [Fact]
            public async Task GetPolicyAsync_WithNonDynamicPolicyName_UsesFallbackProvider()
            {
                // Arrange
                var normalPolicyName = "NormalPolicy";

                // Act
                var policy = await _policyProvider.GetPolicyAsync(normalPolicyName);

                // Assert
                Assert.Null(policy); // Because FallbackProvider returns null in this fake
            }

            [Fact]
            public async Task GetDefaultPolicyAsync_UsesFallbackProvider()
            {
                // Act
                var policy = await _policyProvider.GetDefaultPolicyAsync();

                // Assert
                Assert.NotNull(policy); // DefaultAuthorizationPolicyProvider returns a default policy
            }

            [Fact]
            public async Task GetFallbackPolicyAsync_UsesFallbackProvider()
            {
                // Act
                var policy = await _policyProvider.GetFallbackPolicyAsync();

                // Assert
                Assert.Null(policy); // No fallback policy by default unless configured
            }
        }
    }

