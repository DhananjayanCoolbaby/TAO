﻿using AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Attributes;
using FluentAssertions;
using Xunit;

namespace Test.Authorization.Common.Attributes
{
    public class GlobalAuthorizeAttributeTests
    {
        [Fact]
        public void Constructor_SetsPermissionsAndPolicy()
        {
            // Arrange
            var permissions = new[] { "Read", "Write" };

            // Act
            var attribute = new GlobalAuthorizeAttribute(permissions);

            // Assert
            attribute.Permissions.Should().BeEquivalentTo(permissions);
            attribute.Policy.Should().Be("PermissionPolicy:Read,Write");
        }

        [Fact]
        public void Constructor_WithNoPermissions_SetsEmptyPolicy()
        {
            // Act
            var attribute = new GlobalAuthorizeAttribute();

            // Assert
            attribute.Permissions.Should().BeEmpty();
            attribute.Policy.Should().Be("PermissionPolicy:");
        }
    }
}