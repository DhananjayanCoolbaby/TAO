﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.Authorization.Common.Middlewares
{
    using Xunit;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Configuration;
    using AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Middlewares;
    using FakeItEasy;
    using System.Text;
    using System.Threading.Tasks;

    public class SwaggerAuthMiddlewareTests
    {
        private SwaggerAuthMiddleware CreateMiddleware(
            RequestDelegate next,
            string username = "admin",
            string password = "pass",
            string swaggerPathPrefix = "/swagger")
        {
            var configData = new Dictionary<string, string>
        {
            { "SwaggerAuth:Username", username },
            { "SwaggerAuth:Password", password },
            { "Swagger:PathPrefix", swaggerPathPrefix }
        };

            var configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(configData)
                .Build();

            return new SwaggerAuthMiddleware(next, configuration);
        }

        private string EncodeBasicAuth(string username, string password)
        {
            var authString = $"{username}:{password}";
            return "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(authString));
        }

        [Fact]
        public async Task Allows_Request_With_Valid_Basic_Auth()
        {
            // Arrange
            var wasCalled = false;
            var next = new RequestDelegate(ctx =>
            {
                wasCalled = true;
                return Task.CompletedTask;
            });

            var middleware = CreateMiddleware(next);
            var context = new DefaultHttpContext();
            context.Request.Path = "/swagger/index.html";
            context.Request.Headers["Authorization"] = EncodeBasicAuth("admin", "pass");

            // Act
            await middleware.Invoke(context);

            // Assert
            Assert.True(wasCalled);
            Assert.Equal(200, context.Response.StatusCode); // Default if not explicitly set
        }

        [Fact]
        public async Task Rejects_Request_With_Invalid_Basic_Auth()
        {
            // Arrange
            var next = A.Fake<RequestDelegate>();
            var middleware = CreateMiddleware(next);

            var context = new DefaultHttpContext();
            context.Request.Path = "/swagger/index.html";
            context.Request.Headers["Authorization"] = EncodeBasicAuth("wrong", "creds");

            // Act
            await middleware.Invoke(context);

            // Assert
            Assert.Equal(StatusCodes.Status401Unauthorized, context.Response.StatusCode);
            Assert.Equal("Basic", context.Response.Headers["WWW-Authenticate"]);
        }

        [Fact]
        public async Task Skips_NonSwagger_Request_And_Calls_Next()
        {
            // Arrange
            var wasCalled = false;
            var next = new RequestDelegate(ctx =>
            {
                wasCalled = true;
                return Task.CompletedTask;
            });

            var middleware = CreateMiddleware(next);
            var context = new DefaultHttpContext();
            context.Request.Path = "/api/values";

            // Act
            await middleware.Invoke(context);

            // Assert
            Assert.True(wasCalled);
            Assert.Equal(200, context.Response.StatusCode);
        }
    }
}