﻿using AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Extensions;
using AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Middlewares;
using FakeItEasy;
using FluentAssertions;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Xunit;


namespace Test.Authorization.Common.Extensions
{
    public class ApplicationBuilderExtensionsTests
    {
        [Fact]
        public void UseAuthorizationMiddlewares_UsesSwaggerMiddlewareInDevelopment()
        {
            var appBuilder = A.Fake<IApplicationBuilder>();
            var env = A.Fake<IWebHostEnvironment>();
            A.CallTo(() => env.EnvironmentName).Returns("Development");

            var result = AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Extensions.ApplicationBuilderExtensions.UseAuthorizationMiddlewares(appBuilder, env);

            result.Should().NotBeNull();
        }

        [Fact]
        public void UseAuthorizationMiddlewares_SkipsSwaggerInProduction()
        {
            var appBuilder = A.Fake<IApplicationBuilder>();
            var env = A.Fake<IWebHostEnvironment>();

            A.CallTo(() => env.EnvironmentName).Returns("Production");

            var result = AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Extensions.ApplicationBuilderExtensions.UseAuthorizationMiddlewares(appBuilder, env);

            result.Should().NotBeNull();
        }
    }
}
   