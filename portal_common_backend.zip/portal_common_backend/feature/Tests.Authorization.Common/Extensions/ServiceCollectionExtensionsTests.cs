﻿using AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Extensions;
using AA.PS.FS.Platform.Portal.Utilities.Authorization.Common.Services;
using FluentAssertions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Test.Authorization.Common.Extensions
{
    public class ServiceCollectionExtensionsTests
    {
        [Fact]
        public void AddCommonAuthorizationService_RegistersAllExpectedServices()
        {
            var services = new ServiceCollection();
            var config = new ConfigurationBuilder()
                .AddInMemoryCollection(new Dictionary<string, string>
                {
                    { "IdentitySettings:Issuer", "https://issuer" },
                    { "IdentitySettings:Audience", "aud" },
                    { "IdentitySettings:SecretKey", "thisisaverysecurekey1234567890" }
                })
                .Build();

            services.AddSingleton<IConfiguration>(config); // 🔧 FIX: Register IConfiguration

            var result = services.AddCommonAuthorizationService(config);
            var provider = result.BuildServiceProvider();

            result.Should().NotBeNull();

            provider.GetService<IAuthorizationHandler>()
                .Should().NotBeNull().And.BeOfType<PermissionHandler>();

            provider.GetService<IAuthorizationPolicyProvider>()
                .Should().NotBeNull().And.BeOfType<DynamicPermissionPolicyProvider>();

            provider.GetService<EntraTokenValidator>()
                .Should().NotBeNull();
        }
    }
}
