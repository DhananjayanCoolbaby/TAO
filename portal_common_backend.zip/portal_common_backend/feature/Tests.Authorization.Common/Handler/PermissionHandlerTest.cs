﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Handlers;
using Microsoft.AspNetCore.Authorization;

namespace Test.Authorization.Common.Handler
{
    public class PermissionHandlerTest
    {

    
        private readonly PermissionHandler _handler = new PermissionHandler();

        private ClaimsPrincipal CreateUser(bool isAuthenticated, params string[] permissions)
        {
            var claims = new List<Claim>();
            if (permissions.Any())
            {
                foreach (var permission in permissions)
                    claims.Add(new Claim("Permissions", permission)); // Could be "Read", or "Read,Write"
            }

            var identity = new ClaimsIdentity(claims, isAuthenticated ? "TestAuth" : null);
            return new ClaimsPrincipal(identity);
        }

        private AuthorizationHandlerContext CreateContext(ClaimsPrincipal user, params string[] requiredPermissions)
        {
            var requirement = new PermissionRequirement(requiredPermissions);
            return new AuthorizationHandlerContext(new[] { requirement }, user, null);
        }

        [Fact]
        public async Task Should_Not_Succeed_When_User_Not_Authenticated()
        {
            var user = CreateUser(false, "Read");
            var context = CreateContext(user, "Read");

            await _handler.HandleAsync(context);

            Assert.False(context.HasSucceeded);
        }

        [Fact]
        public async Task Should_Succeed_When_No_Required_Permissions()
        {
            var user = CreateUser(true, "Any");
            var context = CreateContext(user, null); // requirement is null

            await _handler.HandleAsync(context);

            Assert.True(context.HasSucceeded);
        }

        [Fact]
        public async Task Should_Succeed_When_RequiredPermissions_Are_Whitespace()
        {
            var user = CreateUser(true, "Any");
            var context = CreateContext(user, " ", "", "\t");

            await _handler.HandleAsync(context);

            Assert.True(context.HasSucceeded);
        }

        [Fact]
        public async Task Should_Succeed_When_User_Has_All_Permissions()
        {
            var user = CreateUser(true, "Read,Write", "Delete");
            var context = CreateContext(user, "Read", "Write", "Delete");

            await _handler.HandleAsync(context);

            Assert.True(context.HasSucceeded);
        }

        [Fact]
        public async Task Should_Not_Succeed_When_User_Is_Missing_Any_Required_Permission()
        {
            var user = CreateUser(true, "Read", "Write");
            var context = CreateContext(user, "Read", "Write", "Delete");

            await _handler.HandleAsync(context);

            Assert.False(context.HasSucceeded);
        }

        [Fact]
        public async Task Should_Trim_And_Handle_Duplicate_Permissions_Correctly()
        {
            var user = CreateUser(true, " Read , Write ", "Read");
            var context = CreateContext(user, "Read", "Write");

            await _handler.HandleAsync(context);

            Assert.True(context.HasSucceeded);
        }

        [Fact]
        public async Task Should_Support_Multiple_PermissionClaims()
        {
            var user = CreateUser(true, "Read", "Write", "Delete");
            var context = CreateContext(user, "Write", "Delete");

            await _handler.HandleAsync(context);

            Assert.True(context.HasSucceeded);
        }
    }

}
