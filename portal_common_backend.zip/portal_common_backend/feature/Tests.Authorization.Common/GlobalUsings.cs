﻿global using AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Handlers;
global using AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Services;
global using Microsoft.AspNetCore.Authorization;
global using Microsoft.Extensions.Options;
