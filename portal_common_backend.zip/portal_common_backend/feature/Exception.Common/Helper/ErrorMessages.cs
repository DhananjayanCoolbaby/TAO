﻿namespace AA.PS.FS.Platform.Portal.Utilities.Exception.Common.Helper
{
    public static class ErrorMessages
    {
        public const string UnauthorizedAccess = "Unauthorized Access";
        public const string ForbiddenException = "Permission denied";
        public const string ArgumentException = "Bad Request. Invalid argument.";
        public const string KeyNotFoundException = "Resource not found";
        public const string GenericError = "Internal server error";
    }
}
