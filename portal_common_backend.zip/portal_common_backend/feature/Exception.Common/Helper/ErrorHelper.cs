﻿using AA.PS.FS.Platform.Portal.Utilities.Exception.Common.Enum;

namespace AA.PS.FS.Platform.Portal.Utilities.Exception.Common.Helper
{
    public static class ErrorHelper
    {
        public static ApiError FromErrorCode(ErrorCode code, string? entityName = null)
        {
            var message = GetMessage(code, entityName);
            return new ApiError
            {
                Code = code.ToString(),
                Message = message
            };
        }

        private static string GetMessage(ErrorCode code, string? entity = null)
        {
            return code switch
            {
                ErrorCode.EntityNotFound => $"{entity} not found",
                ErrorCode.EntityAlreadyExists => $"{entity} already exists",
                ErrorCode.EntityDataRequired => $"{entity} data is required",
                ErrorCode.InvalidModel => "Invalid model state",
                ErrorCode.OperationSuccessful => $"{entity} operation completed successfully",
                _ => "An unknown error occurred"
            };
        }
    }
}
