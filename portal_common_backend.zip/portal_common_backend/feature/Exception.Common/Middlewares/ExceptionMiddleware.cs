﻿namespace AA.PS.FS.Platform.Portal.Utilities.Exception.Common.Middlewares
{
    public class ExceptionMiddleware : IMiddleware
    {
        private readonly ILoggingService _logger;

        public ExceptionMiddleware(ILoggingService logger)
        {
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            try
            {
                await next(context);
            }
            catch (System.Exception exception)
            {
                await HandleExceptionAsync(context, exception);

                var username = context.User.Identity?.IsAuthenticated == true
                                  ? context.User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                                  : "Anonymous";

                _logger.LogError($"{username} - An unhandled exception occurred while processing the request at {context.Request.Path}", exception);
            }
        }

        private async Task HandleExceptionAsync(HttpContext context, System.Exception exception)
        {
            context.Response.ContentType = "application/json";

            var errorDetails = new ErrorDetails();

            var (statusCode, message) = MapExceptionToResponse(exception);

            context.Response.StatusCode = statusCode;
            errorDetails.StatusCode = statusCode;
            errorDetails.Message = message;


            var jsonErrorResponse = JsonSerializer.Serialize(errorDetails);

            await context.Response.WriteAsync(jsonErrorResponse);
        }


        private (int StatusCode, string Message) MapExceptionToResponse(System.Exception exception)
        {
            return exception switch
            {
                UnauthorizedAccessException => ((int)HttpStatusCode.Unauthorized, ErrorMessages.UnauthorizedAccess),
                System.Exception e when e.Message.StartsWith("Forbidden") => ((int)HttpStatusCode.Forbidden, ErrorMessages.ForbiddenException),
                ValidationException or ArgumentException or ArgumentNullException => ((int)HttpStatusCode.BadRequest, ErrorMessages.ArgumentException),
                KeyNotFoundException => ((int)HttpStatusCode.NotFound, ErrorMessages.KeyNotFoundException),
                _ => ((int)HttpStatusCode.InternalServerError, ErrorMessages.GenericError)
            };
        }
    }
}

