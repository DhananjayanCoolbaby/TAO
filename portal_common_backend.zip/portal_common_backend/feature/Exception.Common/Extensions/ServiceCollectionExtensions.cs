﻿namespace AA.PS.FS.Platform.Portal.Utilities.Exception.Common.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddExceptionService(this IServiceCollection services)
        {
            services.AddScoped<ExceptionMiddleware>();
            return services;
        }

    }
}
