﻿namespace AA.PS.FS.Platform.Portal.Utilities.Exception.Common.Models
{
    public class ErrorDetails
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }
    }
}
