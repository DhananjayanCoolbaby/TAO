﻿namespace AA.PS.FS.Platform.Portal.Utilities.Exception.Common.Models
{
    public class ApiError
    {
        public string Code { get; set; }
        public string Message { get; set; }
    }
}
