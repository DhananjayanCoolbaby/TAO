﻿namespace AA.PS.FS.Platform.Portal.Utilities.Exception.Common.Enum
{
    public enum ErrorCode
    {
        EntityNotFound,
        EntityAlreadyExists,
        EntityDataRequired,
        InvalidModel,
        OperationSuccessful
    }
}
