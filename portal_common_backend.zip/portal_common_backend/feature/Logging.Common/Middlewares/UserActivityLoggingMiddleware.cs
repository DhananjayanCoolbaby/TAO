﻿namespace AA.PS.FS.Platform.Portal.Utilities.Logging.Common.Middlewares
{
    public class UserActivityLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILoggingService _logger;

        public UserActivityLoggingMiddleware(RequestDelegate next, ILoggingService logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var path = context.Request.Path.Value?.ToLowerInvariant();
            // Skip logging for the root path and swagger
            if (path == "/" || path.Contains("swagger") ||
                path.Contains("/lastsyncdetails"))
            {
                await _next(context);
                return;
            }

            var username = context.User.Identity?.IsAuthenticated == true
                ? context.User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                : "Anonymous";

            var method = context.Request.Method;

            string logMessage = $"User: {username}, Method: {method}, Path: {path}, Time: {DateTime.UtcNow}";
            _logger.LogInformation(logMessage);
            await _next(context);
        }
    }

}
