﻿global using System.Security.Claims;
global using AA.PS.FS.Platform.Portal.Utilities.Logging.Common.Application.Interfaces;
global using AA.PS.FS.Platform.Portal.Utilities.Logging.Common.Infrastructure.Logging;
global using Microsoft.AspNetCore.Http;
global using Microsoft.Extensions.Configuration;
global using Microsoft.Extensions.DependencyInjection;
global using Microsoft.Extensions.Logging;
global using Serilog;
