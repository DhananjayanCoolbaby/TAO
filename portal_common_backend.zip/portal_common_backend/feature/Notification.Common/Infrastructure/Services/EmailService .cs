﻿namespace AA.PS.FS.Platform.Portal.Utilities.Notification.Common.Infrastructure.Services
{
    public class EmailService : IEmailService
    {
        private readonly EmailClient _client;
        private readonly string _sender;
        private readonly int _retryCount;

        public EmailService(string connectionString, string senderAddress, int retryCount)
        {
          //  _client = new EmailClient(connectionString);
            _sender = senderAddress;
            _retryCount = retryCount;
        }

        public async Task SendEmailAsync(
            IEnumerable<string> to,
            string subject,
            string body,
            bool isHtml = false,
            IEnumerable<string>? cc = null,
            IEnumerable<string>? bcc = null,
            IEnumerable<(string FileName, byte[] Content, string ContentType)>? attachments = null)
        {
            if (to == null || !to.Any())
                throw new ArgumentException("At least one 'To' recipient is required.", nameof(to));

            if (string.IsNullOrWhiteSpace(subject))
                throw new ArgumentException("Email subject cannot be empty.", nameof(subject));

            if (string.IsNullOrWhiteSpace(body))
                throw new ArgumentException("Email body cannot be empty.", nameof(body));

            var content = new EmailContent(subject)
            {
                PlainText = isHtml ? null : body,
                Html = isHtml ? body : null
            };

            //var senderAddress = new EmailAddress(_sender)
            //{
            //    DisplayName = _senderDisplayName
            //};


            var toList = to.Select(addr => new EmailAddress(addr)).ToList();
            var ccList = cc?.Select(addr => new EmailAddress(addr)).ToList() ?? new List<EmailAddress>();
            var bccList = bcc?.Select(addr => new EmailAddress(addr)).ToList() ?? new List<EmailAddress>();

            var emailRecipients = new EmailRecipients(to: toList, cc: ccList, bcc: bccList);

            var message = new EmailMessage(_sender, emailRecipients, content);

            if (attachments != null)
            {
                foreach (var attachment in attachments)
                {
                    if (attachment.Content == null || string.IsNullOrWhiteSpace(attachment.FileName))
                        continue; // Skip invalid entries

                    message.Attachments.Add(new EmailAttachment(
                        attachment.FileName,
                        attachment.ContentType,
                        BinaryData.FromBytes(attachment.Content)
                    ));
                }
            }

            AsyncRetryPolicy retryPolicy = Policy
                 .Handle<Exception>()
                 .WaitAndRetryAsync(
                     _retryCount,
                     attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt)),
                     (exception, timespan, retryCount, context) =>
                     {
                         //Console.WriteLine($"Retry {retryCount} after {timespan.TotalSeconds}s due to: {exception.Message}");
                     }
                 );

            await retryPolicy.ExecuteAsync(async () =>
            {
                EmailSendOperation operation = await _client.SendAsync(Azure.WaitUntil.Completed, message);
                EmailSendResult result = operation.Value;

                if (!operation.HasCompleted || !operation.HasValue)
                    throw new InvalidOperationException("Email send operation did not complete successfully.");
            });
        }
    }
}

