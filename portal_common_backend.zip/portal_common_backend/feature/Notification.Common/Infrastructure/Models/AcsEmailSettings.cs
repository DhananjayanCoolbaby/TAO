﻿namespace AA.PS.FS.Platform.Portal.Utilities.Notification.Common.Infrastructure.Models
{
    public class AcsEmailSettings
    {
        public string ConnectionString { get; set; } = string.Empty;
        public string Sender { get; set; } = string.Empty;
        public int RetryCount { get; set; } = 3;
    }
}
