﻿namespace AA.PS.FS.Platform.Portal.Utilities.Notification.Common.Application.Interfaces
{
    public interface IEmailService
    {
       Task SendEmailAsync(
             IEnumerable<string> to,
             string subject,
             string body,
             bool isHtml = false,
             IEnumerable<string>? cc = null,
             IEnumerable<string>? bcc = null,
             IEnumerable<(string FileName, byte[] Content, string ContentType)>? attachments = null);
    }
}
