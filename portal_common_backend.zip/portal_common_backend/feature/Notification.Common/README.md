# Notification.Common Package

A shared library for sending emails via Azure Communication Services (ACS) with built-in retry logic using Polly.

## Version

**Current Version:** 1.0.2

## Features

- Email sending via Azure Communication Services
- Configurable retry policy with exponential backoff
- Support for HTML and plain text emails
- CC and BCC recipients support
- KeyVault integration for secure configuration

---

## Prerequisites

### Framework Requirements
- **.NET 9.0** or higher

### Required Azure Services
- **Azure Communication Services (ACS)** with Email configured
- **Azure Key Vault** (optional, for secure configuration storage)

---

## Installation

### From NuGet/Azure Artifacts Feed

```bash
dotnet add package AA.PS.FS.Platform.Portal.Utilities.Notification.Common --version 1.0.1
```

### From Local Build

```bash
dotnet add reference path/to/Notification.Common.csproj
```

---

## ⚠️ Important: Azure App Service Deployment

When deploying applications that use this package to **Azure App Service**, you **MUST** add the following packages explicitly to your main application's `.csproj` file to avoid runtime errors:

### Add to Your Main Application's `.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <PropertyGroup>
    <TargetFramework>net9.0</TargetFramework>
    <!-- CRITICAL: This ensures ALL dependencies are copied -->
    <CopyLocalLockFileAssemblies>true</CopyLocalLockFileAssemblies>
    <!-- CRITICAL: This includes all runtime dependencies -->
    <PublishSingleFile>false</PublishSingleFile>
    <SelfContained>false</SelfContained>
  </PropertyGroup>

  <ItemGroup>
    <!-- Reference the Notification.Common package -->
    <PackageReference Include="AA.PS.FS.Platform.Portal.Utilities.Notification.Common" Version="1.0.2" />
    
    <!-- REQUIRED: These MUST be explicitly referenced in your main app -->
    <PackageReference Include="Azure.Core" Version="1.49.0" />
    <PackageReference Include="System.Memory.Data" Version="8.0.1" />
    <PackageReference Include="System.ClientModel" Version="1.7.0" />
    <PackageReference Include="Azure.Communication.Email" Version="1.1.0" />
  </ItemGroup>

</Project>
```

### ⚠️ CRITICAL: You MUST do ALL of these steps:

**Step 1: Update your main application's .csproj with ALL packages above**

**Step 2: Clean everything (REQUIRED)**
```bash
dotnet clean
# Manually delete bin and obj folders
Remove-Item -Recurse -Force bin, obj
```

**Step 3: Restore and rebuild**
```bash
dotnet restore --force
dotnet build --no-incremental
```

**Step 4: Verify DLLs before deploying**
```bash
dotnet publish -c Release -o ./publish

# Verify these DLLs exist in publish folder:
ls ./publish/System.Memory.Data.dll
ls ./publish/Azure.Core.dll
ls ./publish/System.ClientModel.dll
```

**Step 5: If any DLL is missing, check your publish profile**

If using a publish profile (`.pubxml`), ensure it has:
```xml
<PropertyGroup>
  <PublishSingleFile>false</PublishSingleFile>
  <SelfContained>false</SelfContained>
  <PreserveCompilationContext>true</PreserveCompilationContext>
</PropertyGroup>
```

### Critical Steps After Adding Packages:

1. **Clean the solution:**
   ```bash
   dotnet clean
   ```

2. **Restore packages:**
   ```bash
   dotnet restore
   ```

3. **Rebuild completely:**
   ```bash
   dotnet build --no-incremental
   ```

4. **Verify packages in publish output:**
   ```bash
   dotnet publish -c Release -o ./publish
   # Check that System.Memory.Data.dll exists in ./publish folder
   ```

5. **Redeploy to Azure App Service** (ensure you're deploying from the clean build)

**Why is this needed?**  
Azure App Service uses a clean deployment environment. Without explicit references and the `CopyLocalLockFileAssemblies` property, transitive dependencies (`Azure.Core`, `System.Memory.Data`, and `System.ClientModel`) may not be included in the deployment package, causing `FileNotFoundException` or `TypeLoadException` at runtime.

---

## Configuration

### appsettings.json

Add the following configuration section to your `appsettings.json`:

```json
{
  "ACS": {
    "EmailSettings": {
      "ConnectionString": "endpoint=https://your-acs-resource.communication.azure.com/;accesskey=your-key",
      "Sender": "DoNotReply@your-domain.com",
      "RetryCount": 3
    }
  }
}
```

### Using Azure Key Vault (Recommended for Production)

Store sensitive values in Azure Key Vault and reference them:

```json
{
  "ACS": {
    "EmailSettings": {
      "ConnectionString": "@Microsoft.KeyVault(SecretUri=https://your-vault.vault.azure.net/secrets/acs-connection-string/)",
      "Sender": "DoNotReply@your-domain.com",
      "RetryCount": 3
    }
  }
}
```

---

## Usage

### 1. Register the Service

In your `Program.cs` or `Startup.cs`:

```csharp
using AA.PS.FS.Platform.Portal.Utilities.Notification.Common.Extensions;

var builder = WebApplication.CreateBuilder(args);

// Register Email Service
builder.Services.AddCommonEmailService(builder.Configuration);

var app = builder.Build();
```

### 2. Inject and Use the Service

```csharp
using AA.PS.FS.Platform.Portal.Utilities.Notification.Common.Application.Interfaces;

public class YourController : ControllerBase
{
    private readonly IEmailService _emailService;

    public YourController(IEmailService emailService)
    {
        _emailService = emailService;
    }

    public async Task<IActionResult> SendNotification()
    {
        try
        {
            await _emailService.SendEmailAsync(
                to: new[] { "recipient@example.com" },
                subject: "Welcome!",
                body: "<h1>Hello World</h1>",
                isHtml: true,
                cc: new[] { "cc@example.com" },
                bcc: new[] { "bcc@example.com" }
            );

            return Ok("Email sent successfully");
        }
        catch (Exception ex)
        {
            // Handle exception
            return StatusCode(500, ex.Message);
        }
    }
}
```

### 3. Send Plain Text Email

```csharp
await _emailService.SendEmailAsync(
    to: new[] { "user@example.com" },
    subject: "Plain Text Email",
    body: "This is a plain text email",
    isHtml: false
);
```

---

## API Reference

### IEmailService.SendEmailAsync

Sends an email using Azure Communication Services.

#### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `to` | `IEnumerable<string>` | Yes | List of recipient email addresses |
| `subject` | `string` | Yes | Email subject line |
| `body` | `string` | Yes | Email body content |
| `isHtml` | `bool?` | No | Whether the body is HTML (default: false) |
| `cc` | `IEnumerable<string>` | No | List of CC recipients |
| `bcc` | `IEnumerable<string>` | No | List of BCC recipients |

#### Returns
`Task` - Completes when the email is sent successfully

#### Exceptions
- `ArgumentException` - Thrown when required parameters are missing or invalid
- `InvalidOperationException` - Thrown when the email send operation fails
- `Exception` - Other exceptions from Azure Communication Services

---

## Retry Policy

The service includes automatic retry logic with exponential backoff:

- **Default Retry Count:** Configurable via `appsettings.json` (`RetryCount`)
- **Retry Delay:** Exponential backoff (2^attempt seconds)
  - 1st retry: 2 seconds
  - 2nd retry: 4 seconds
  - 3rd retry: 8 seconds

---

## Troubleshooting

### Common Issues

#### 1. `FileNotFoundException: System.Memory.Data`

**Error:** `Could not load file or assembly 'System.Memory.Data, Version=8.0.0.1'`

**Solution:** Add explicit package reference to your main application:
```xml
<PackageReference Include="System.Memory.Data" Version="8.0.1" />
```

#### 2. `TypeLoadException: Method 'AsPages' not implemented`

**Error:** `Method 'AsPages' in type 'FuncAsyncPageable' does not have an implementation`

**Solution:** Ensure you're using Notification.Common v1.0.1 or higher, which includes the updated Azure packages.

#### 3. Works Locally But Fails in Azure

**Cause:** Transitive dependencies not included in deployment.

**Solution:** Add explicit references to your main application as documented above in the "Azure App Service Deployment" section.

---

## Dependencies

This package depends on the following NuGet packages:

| Package | Version | Purpose |
|---------|---------|---------|
| `Azure.Communication.Email` | 1.1.0 | Azure Communication Services email client |
| `Azure.Core` | 1.49.0 | Azure SDK core library |
| `Azure.Identity` | 1.14.2 | Azure authentication |
| `Azure.Security.KeyVault.Secrets` | 4.8.0 | Key Vault access |
| `Polly` | 8.6.2 | Retry policy implementation |
| `System.Memory.Data` | 8.0.1 | Memory management utilities |
| `System.ClientModel` | 1.7.0 | Azure SDK client model abstractions |

---

## Example: Complete Setup

### 1. Main Application `.csproj`

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <PropertyGroup>
    <TargetFramework>net9.0</TargetFramework>
  </PropertyGroup>

  <ItemGroup>
    <!-- Notification.Common package -->
    <PackageReference Include="AA.PS.FS.Platform.Portal.Utilities.Notification.Common" Version="1.0.2" />
    
    <!-- Required for Azure App Service deployment -->
    <PackageReference Include="Azure.Core" Version="1.49.0" />
    <PackageReference Include="System.Memory.Data" Version="8.0.1" />
    <PackageReference Include="System.ClientModel" Version="1.7.0" />
  </ItemGroup>

</Project>
```

### 2. Program.cs

```csharp
using AA.PS.FS.Platform.Portal.Utilities.Notification.Common.Extensions;

var builder = WebApplication.CreateBuilder(args);

// Add services
builder.Services.AddControllers();
builder.Services.AddCommonEmailService(builder.Configuration);

var app = builder.Build();

app.UseRouting();
app.MapControllers();

app.Run();
```

### 3. appsettings.json

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information"
    }
  },
  "ACS": {
    "EmailSettings": {
      "ConnectionString": "endpoint=https://your-acs.communication.azure.com/;accesskey=your-key",
      "Sender": "noreply@yourdomain.com",
      "RetryCount": 3
    }
  }
}
```

### 4. Controller Usage

```csharp
using Microsoft.AspNetCore.Mvc;
using AA.PS.FS.Platform.Portal.Utilities.Notification.Common.Application.Interfaces;

[ApiController]
[Route("api/[controller]")]
public class NotificationController : ControllerBase
{
    private readonly IEmailService _emailService;

    public NotificationController(IEmailService emailService)
    {
        _emailService = emailService;
    }

    [HttpPost("send")]
    public async Task<IActionResult> SendEmail([FromBody] EmailRequest request)
    {
        await _emailService.SendEmailAsync(
            to: request.Recipients,
            subject: request.Subject,
            body: request.Body,
            isHtml: true
        );

        return Ok("Email sent successfully");
    }
}

public record EmailRequest(
    string[] Recipients,
    string Subject,
    string Body
);
```

---

## Support

For issues or questions:
1. Check the **Troubleshooting** section above
2. Review Azure Communication Services documentation
3. Contact the platform team

---

## Changelog

### v1.0.1 (Current)
- ✅ Updated `Azure.Communication.Email` to v1.1.0
- ✅ Added explicit `Azure.Core` v1.49.0 reference
- ✅ Added `System.Memory.Data` v8.0.1 for Azure deployment compatibility
- ✅ Fixed TypeLoadException for `AsPages()` method
- ✅ Fixed FileNotFoundException in Azure App Service deployments
- ✅ Added `PrivateAssets="none"` to critical dependencies for proper transitive dependency flow

### v1.0.0
- Initial release
- Azure Communication Services email integration
- Polly retry policy support
- Basic email sending functionality

---

## License

Arabella-Advisors

