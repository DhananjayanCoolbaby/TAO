﻿namespace AA.PS.FS.Platform.Portal.Utilities.Notification.Common.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddCommonEmailService(
           this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<AcsEmailSettings>(configuration.GetSection("ACS:EmailSettings"));
            services.AddScoped<IEmailService>(sp =>
            {
                var emailSettings = sp.GetRequiredService<IOptions<AcsEmailSettings>>().Value;

                return new EmailService(
                     KeyVaultHelper.GetSecretValue(configuration, "ACS:EmailSettings:ConnectionString"),
                     KeyVaultHelper.GetSecretValue(configuration, "ACS:EmailSettings:Sender"),
                    // KeyVaultHelper.GetSecretValue(configuration, emailSettings.ConnectionString),
                    //KeyVaultHelper.GetSecretValue(configuration, emailSettings.Sender),
                    emailSettings.RetryCount
                );
            });
            return services;
        }
    }
}
