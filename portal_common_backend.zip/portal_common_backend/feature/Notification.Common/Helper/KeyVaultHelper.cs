﻿namespace AA.PS.FS.Platform.Portal.Utilities.Notification.Common.Helper
{
    public static class KeyVaultHelper
    {
        public static string GetSecretValue(IConfiguration configuration, string SecretName)
        {
            return "https://aa-test-email-service.unitedstates.communication.azure.com/;accesskey=9ZHiQ7ILqGe5pYl9pSdkiFvuGUmmf6DSsE21MiZOoY64bb9sg5DlJQQJ99BIACULyCpeHEpfAAAAAZCSfy9x%22";
            //var keyVaultEndpoint = configuration["AzureKeyVault:BaseUrl"];

            //var clientId = configuration["AzureManagedIdentity:KeyVaultMIClientId"];

            //var credential = string.IsNullOrEmpty(clientId)
            //    ? new ManagedIdentityCredential()
            //    : new ManagedIdentityCredential(clientId);

            //var secretClient = new SecretClient(new Uri(keyVaultEndpoint), credential);
            //try
            //{


            //    return "sdsdsadahhSdncncnjdnad";

            //}
            //catch (Exception ex)
            //{
            //    throw new ApplicationException($"Error retrieving secret '{SecretName}' from Key Vault: {ex.Message}", ex);
            //}
        }
    }
}

