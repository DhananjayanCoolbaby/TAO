# 🔧 Azure App Service Deployment Fix

## Problem
`FileNotFoundException: Could not load file or assembly 'System.Memory.Data, Version=8.0.0.1'`

## Root Cause
Transitive dependencies (`System.Memory.Data`, `Azure.Core`, `System.ClientModel`) from `Azure.Communication.Email` are not being deployed to Azure App Service.

---

## ✅ IMMEDIATE FIX - Do These Steps Now

### Step 1: Update Your Main Application's `.csproj`

Add these to your **main web application** project file:

```xml
<PropertyGroup>
  <TargetFramework>net9.0</TargetFramework>
  
  <!-- ADD THESE PROPERTIES -->
  <CopyLocalLockFileAssemblies>true</CopyLocalLockFileAssemblies>
  <PublishSingleFile>false</PublishSingleFile>
  <SelfContained>false</SelfContained>
</PropertyGroup>

<ItemGroup>
  <!-- Your existing packages... -->
  
  <!-- ADD ALL FOUR OF THESE EXPLICITLY -->
  <PackageReference Include="Azure.Communication.Email" Version="1.1.0" />
  <PackageReference Include="Azure.Core" Version="1.49.0" />
  <PackageReference Include="System.Memory.Data" Version="8.0.1" />
  <PackageReference Include="System.ClientModel" Version="1.7.0" />
</ItemGroup>
```

### Step 2: Clean Build (CRITICAL!)

Run these commands in PowerShell from your main app directory:

```powershell
# Clean
dotnet clean

# Delete bin/obj manually (important!)
Remove-Item -Recurse -Force bin, obj

# Force restore
dotnet restore --force

# Build fresh
dotnet build --no-incremental -c Release
```

### Step 3: Verify Before Deploying

```powershell
# Publish locally to test
dotnet publish -c Release -o ./publish

# CHECK: These DLLs MUST exist in ./publish folder
Get-ChildItem ./publish -Filter "System.Memory.Data.dll"
Get-ChildItem ./publish -Filter "Azure.Core.dll"
Get-ChildItem ./publish -Filter "System.ClientModel.dll"
```

**If ANY of these DLLs are missing, DO NOT DEPLOY YET!**

### Step 4: Check Your Azure DevOps Pipeline

If you're using Azure DevOps, update your pipeline YAML:

```yaml
- task: DotNetCoreCLI@2
  displayName: 'Publish'
  inputs:
    command: 'publish'
    publishWebProjects: true
    arguments: '--configuration Release --output $(Build.ArtifactStagingDirectory) --no-restore'
    zipAfterPublish: true
    modifyOutputPath: false
```

Make sure:
- ✅ `--no-restore` is present (restore should be a separate step)
- ✅ No `PublishSingleFile` or trimming options
- ✅ `zipAfterPublish: true` is set

### Step 5: Update Notification.Common Reference

Update your reference to use version **1.0.2**:

```xml
<PackageReference Include="AA.PS.FS.Platform.Portal.Utilities.Notification.Common" Version="1.0.2" />
```

### Step 6: Deploy to Azure

After completing steps 1-5 and verifying DLLs exist in publish output, deploy to Azure App Service.

---

## 📋 Complete Example for Main App

Your main application's `.csproj` should look like this:

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <PropertyGroup>
    <TargetFramework>net9.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
    
    <!-- Ensure all dependencies are deployed -->
    <CopyLocalLockFileAssemblies>true</CopyLocalLockFileAssemblies>
    <PublishSingleFile>false</PublishSingleFile>
    <SelfContained>false</SelfContained>
  </PropertyGroup>

  <ItemGroup>
    <!-- Your existing packages -->
    
    <!-- Notification.Common -->
    <PackageReference Include="AA.PS.FS.Platform.Portal.Utilities.Notification.Common" Version="1.0.2" />
    
    <!-- REQUIRED: Explicit Azure dependencies -->
    <PackageReference Include="Azure.Communication.Email" Version="1.1.0" />
    <PackageReference Include="Azure.Core" Version="1.49.0" />
    <PackageReference Include="System.Memory.Data" Version="8.0.1" />
    <PackageReference Include="System.ClientModel" Version="1.7.0" />
    
    <!-- Your other packages... -->
  </ItemGroup>

</Project>
```

---

## 🔍 Troubleshooting

### If Error Still Occurs After Following Steps:

**1. Check your publish profile** (`.pubxml` file):

```xml
<PropertyGroup>
  <PublishSingleFile>false</PublishSingleFile>
  <SelfContained>false</SelfContained>
  <PreserveCompilationContext>true</PreserveCompilationContext>
</PropertyGroup>
```

**2. Manually check Azure App Service files:**

Use Kudu console (`https://your-app.scm.azurewebsites.net`) and verify:
```
/home/site/wwwroot/System.Memory.Data.dll
```

**3. Check Azure App Service Configuration:**
- .NET version should be .NET 9
- No conflicting app settings
- Restart the app service after deployment

**4. Enable detailed error messages temporarily:**

In `appsettings.json` (for debugging only):
```json
{
  "DetailedErrors": true,
  "Logging": {
    "LogLevel": {
      "Default": "Debug"
    }
  }
}
```

---

## 📞 Still Having Issues?

If the error persists after following ALL steps above:

1. Share your main application's `.csproj` file
2. Share your Azure DevOps pipeline YAML (if using)
3. Confirm you deleted `bin` and `obj` folders
4. Confirm `System.Memory.Data.dll` exists in your publish output
5. Check Azure App Service logs for additional errors

---

## ✅ Changes Made to Notification.Common v1.0.2

- Updated `Azure.Communication.Email` to 1.1.0
- Pinned `Azure.Core` to 1.49.0
- Added explicit `System.Memory.Data` 8.0.1
- Added `System.ClientModel` 1.7.0
- Configured packages with `IncludeAssets=all` and `PrivateAssets=none`
- Added `CopyLocalLockFileAssemblies=true` to ensure DLL copying

These changes ensure dependencies flow through to consuming applications, but **you still must add the explicit references in your main app** as shown above.

