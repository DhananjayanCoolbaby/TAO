﻿namespace AA.PS.FS.Platform.Portal.Utilities.Storage.Common.Application.Interfaces
{
    public interface IBlobFileService
    {
        Task<List<string>> UploadFilesAsync(List<IFormFile> files, string container, string blobPath);
        Task<(Stream FileStream, string ContentType, string FileName)> DownloadFileAsync(string filePath, string NPOId);
        Task<Dictionary<string, bool>> DeleteFilesAsync(IEnumerable<string> fileNames, string container);
        Task<List<string>> UploadFilesWithDocumentAsync(List<IFormFile> files, string container, string blobPath);
    }
}
