﻿namespace AA.PS.FS.Platform.Portal.Utilities.Storage.Common.Infrastructure.Services
{
    public class BlobFileService : IBlobFileService
    {
        private readonly string _connectionString;

        public BlobFileService(IConfiguration configuration)
        {
            _connectionString = configuration["AzureBlobStorage:ConnectionString"];
        }

        public async Task<List<string>> UploadFilesAsync(List<IFormFile> files, string container, string blobPath)
        {
            var uploadedUrls = new List<string>();

            var containerClient = new BlobContainerClient(_connectionString, container.ToLower());

            await containerClient.CreateIfNotExistsAsync();

            foreach (var file in files)
            {
                if (file.Length > 0)
                {
                    var blobName = $"{blobPath}/{Path.GetFileName(file.FileName)}";
                    BlobClient blobClient = containerClient.GetBlobClient(blobName);

                    if (!await blobClient.ExistsAsync())
                    {
                        using var stream = file.OpenReadStream();
                        await blobClient.UploadAsync(stream, new BlobHttpHeaders { ContentType = file.ContentType });
                        uploadedUrls.Add(blobName);
                    }
                }
            }

            return uploadedUrls;
        }

        public async Task<(Stream FileStream, string ContentType, string FileName)> DownloadFileAsync(string filePath, string container)
        {
            var containerClient = new BlobContainerClient(_connectionString, container.ToLower());
            var blobClient = containerClient.GetBlobClient(filePath);

            if (!await blobClient.ExistsAsync())
                throw new FileNotFoundException("Blob not found", filePath);

            var downloadInfo = await blobClient.DownloadAsync();

            return (
                downloadInfo.Value.Content,
                downloadInfo.Value.Details.ContentType ?? "application/octet-stream",
                Path.GetFileName(filePath)
            );
        }
        public async Task<Dictionary<string, bool>> DeleteFilesAsync(IEnumerable<string> fileNames, string container)
        {
            var containerClient = new BlobContainerClient(_connectionString, container.ToLower());

            var deleteFiles = fileNames.Select(async fileName =>
            {
                var blobClient = containerClient.GetBlobClient(fileName);
                var deleted = await blobClient.DeleteIfExistsAsync();
                return new KeyValuePair<string, bool>(fileName, deleted);
            });

            var results = await Task.WhenAll(deleteFiles);
            return results.ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
        }
        public async Task<List<string>> UploadFilesWithDocumentAsync(List<IFormFile> files, string container, string blobPath)
        {
            var uploadedUrls = new List<string>();
            var containerClient = new BlobContainerClient(_connectionString, container.ToLower());

            await containerClient.CreateIfNotExistsAsync();

            foreach (var file in files)
            {
                if (file == null || file.Length == 0)
                    continue;

                // Extract documentId and clean filename
                var fileName = Path.GetFileName(file.FileName);
                var parts = Path.GetFileNameWithoutExtension(fileName)
                    .Split("__", 2, StringSplitOptions.RemoveEmptyEntries);

                string documentId = parts.Length > 1 ? parts[0] : null;
                string originalFileName = parts.Length > 1 ? parts[1] + Path.GetExtension(fileName) : fileName;

                // Construct blob name (include documentId folder if present)
                string blobName = !string.IsNullOrEmpty(documentId)
                    ? $"{blobPath}/document/{documentId}/{originalFileName}"
                    : $"{blobPath}/{originalFileName}";

                var blobClient = containerClient.GetBlobClient(blobName);

                if (!await blobClient.ExistsAsync())
                {
                    using var stream = file.OpenReadStream();
                    await blobClient.UploadAsync(stream, new BlobHttpHeaders { ContentType = file.ContentType });
                    uploadedUrls.Add(blobName);
                }
            }

            return uploadedUrls;
        }
    }
}
