﻿namespace AA.PS.FS.Platform.Portal.Utilities.Storage.Common.Middlewares
{
    public class BlobFileStorageMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IBlobFileService _blobFileService;

        public BlobFileStorageMiddleware(RequestDelegate next, IBlobFileService blobFileService)
        {
            _next = next;
            _blobFileService = blobFileService;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            await _next(context);
        }
    }
}

