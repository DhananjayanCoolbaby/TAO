﻿

namespace AA.PS.FS.Platform.Portal.Utilities.Storage.Common.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddCommonBlobService(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IBlobFileService, BlobFileService>();
            return services;
        }
    }
}
