﻿namespace AA.PS.FS.Platform.Portal.Utilities.Storage.Common.Extensions
{
    public static class ApplicationBuilderExtensions
    {
        public static IApplicationBuilder UseFileHandling(this IApplicationBuilder app)
        {
            return app.UseMiddleware<BlobFileStorageMiddleware>();
        }
    }
}
