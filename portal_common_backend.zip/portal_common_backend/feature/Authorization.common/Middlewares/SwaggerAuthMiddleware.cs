﻿namespace AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Middlewares
{
    public class SwaggerAuthMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly string _username;
        private readonly string _password;
        private readonly string _swaggerPathPrefix;

        public SwaggerAuthMiddleware(RequestDelegate next, IConfiguration configuration)
        {
            _next = next;
            _username = configuration["SwaggerAuth:Username"];
            _password = configuration["SwaggerAuth:Password"];
            _swaggerPathPrefix = configuration["Swagger:PathPrefix"] ?? "/swagger";
        }

        public async Task Invoke(HttpContext context)
        {
            if (context.Request.Path.StartsWithSegments(_swaggerPathPrefix))
            {
                string authHeader = context.Request.Headers["Authorization"];

                if (authHeader != null && authHeader.StartsWith("Basic ", StringComparison.OrdinalIgnoreCase))
                {
                    var encodedUsernamePassword = authHeader.Substring("Basic ".Length).Trim();
                    var decodedUsernamePassword = Encoding.UTF8.GetString(Convert.FromBase64String(encodedUsernamePassword));
                    var parts = decodedUsernamePassword.Split(':', 2);

                    if (parts.Length == 2 && parts[0] == _username && parts[1] == _password)
                    {
                        await _next(context);
                        return;
                    }
                }

                // Challenge
                context.Response.Headers["WWW-Authenticate"] = "Basic";
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                await context.Response.WriteAsync("Unauthorized");
                return;
            }

            await _next(context);
        }
    }
}
