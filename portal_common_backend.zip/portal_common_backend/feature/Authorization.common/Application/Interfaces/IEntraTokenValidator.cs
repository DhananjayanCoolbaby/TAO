﻿namespace AA.PS.FS.Platform.Portal.Utilities.Authorization.Common.Application.Interfaces
{
    public interface IEntraTokenValidator
    {
        Task<bool> ValidateTokenAsync(string token, IConfiguration _configuration);
    }
}
