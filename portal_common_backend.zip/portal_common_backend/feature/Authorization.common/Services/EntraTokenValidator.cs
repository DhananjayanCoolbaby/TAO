﻿namespace AA.PS.FS.Platform.Portal.Utilities.Authorization.Common.Services
{
    public class EntraTokenValidator : IEntraTokenValidator
    {
        public async Task<bool> ValidateTokenAsync(string token, IConfiguration configuration)
        {
            if (string.IsNullOrWhiteSpace(token))
                return false;

            var tenantId = configuration["AzureAd:TenantId"];
            var clientId = configuration["AzureAd:ClientId"];
            var issuerTemplate = configuration["AzureAd:Issuer"];
            var metadataTemplate = configuration["AzureAd:MetadataAddress"];

            // Replace placeholder with actual tenant ID
            var issuer = issuerTemplate.Replace("{tenant-id}", tenantId, StringComparison.OrdinalIgnoreCase);
            var metadataAddress = metadataTemplate.Replace("{tenant-id}", tenantId, StringComparison.OrdinalIgnoreCase);

            if (string.IsNullOrWhiteSpace(clientId) || string.IsNullOrWhiteSpace(issuer) || string.IsNullOrWhiteSpace(metadataAddress))
                return false;

            var configManager = new ConfigurationManager<OpenIdConnectConfiguration>(
                metadataAddress,
                new OpenIdConnectConfigurationRetriever(),
                new HttpDocumentRetriever { RequireHttps = true });

            try
            {
                var openIdConfig = await configManager.GetConfigurationAsync(CancellationToken.None);

                var validationParams = new TokenValidationParameters
                {
                    ValidIssuer = issuer,
                    ValidAudience = clientId,
                    IssuerSigningKeys = openIdConfig.SigningKeys,
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true
                };

                var handler = new JwtSecurityTokenHandler();
                var principal = handler.ValidateToken(token, validationParams, out _);

                return principal.Identity?.IsAuthenticated ?? false;
            }
            catch
            {
                return false;
            }
        }
    }
}
