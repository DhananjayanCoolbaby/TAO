﻿namespace AA.PS.FS.Platform.Portal.Utilities.Authorization.Common.Helpers
{
    public static class KeyVaultHelper
    {
        public static string GetSecretValue(IConfiguration configuration)
        {
            //var keyVaultEndpoint = configuration["AzureKeyVault:BaseUrl"];
            //var secretName = configuration["AzureKeyVault:SecretName"];
            //var clientId = configuration["AzureManagedIdentity:KeyVaultMIClientId"];

            //var credential = string.IsNullOrEmpty(clientId)
            //    ? new ManagedIdentityCredential()
            //    : new ManagedIdentityCredential(clientId);

            //var secretClient = new SecretClient(new Uri(keyVaultEndpoint), credential);
            //try
            //{
            //    KeyVaultSecret secret = secretClient.GetSecret(secretName);
            //    return secret.Value;
            //}
            //catch (Exception ex)
            //{
            //    throw new ApplicationException($"Error retrieving secret '{secretName}' from Key Vault: {ex.Message}", ex);
            //}
            return "u7X9qP4sT1vZ8mC2rL6yN0aF3jW5kH1d";
        }
    }
}
