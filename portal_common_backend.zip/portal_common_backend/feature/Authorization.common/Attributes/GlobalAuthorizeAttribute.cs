﻿namespace AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Attributes
{
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, AllowMultiple = true)]
    public class GlobalAuthorizeAttribute : AuthorizeAttribute
    {
        public string[] Permissions { get; }

        public GlobalAuthorizeAttribute(params string[] permissions)
        {
            Permissions = permissions;
            Policy = $"PermissionPolicy:{string.Join(",", permissions)}";
        }
    }
}
