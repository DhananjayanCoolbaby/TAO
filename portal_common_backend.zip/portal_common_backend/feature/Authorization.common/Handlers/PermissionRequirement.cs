﻿namespace AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Handlers
{
    public class PermissionRequirement : IAuthorizationRequirement
    {
        public string[] RequiredPermissions { get; }

        public PermissionRequirement(string[] requiredPermissions)
        {
            RequiredPermissions = requiredPermissions;
        }
    }
}
