﻿namespace AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Handlers
{
    public class PermissionHandler : AuthorizationHandler<PermissionRequirement>
    {
        private readonly GlobalDatabaseReadOnlyContext _readContext;
        public PermissionHandler(GlobalDatabaseReadOnlyContext readContext)
        {
            _readContext = readContext;
        }

        protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, PermissionRequirement requirement)
        {
            //if (!context.User.Identity?.IsAuthenticated ?? false)
            //{
            //    throw new Exception("Forbidden: User is not authenticated."); // Don't succeed for unauthenticated users
            //}
            // If no specific permissions required 
            if (requirement.RequiredPermissions == null || requirement.RequiredPermissions.All(p => string.IsNullOrWhiteSpace(p)))
            {
                context.Succeed(requirement);
                return;
            }

            var userId = context.User.FindAll("UserId").FirstOrDefault().Value;

            var user = await _readContext.Users
                      .Where(u => u.Id == userId && u.IsActive)
                      .Include(u => u.UserRoles)
                          .ThenInclude(ur => ur.Role)
                              .ThenInclude(r => r.RolePermissions)
                                  .ThenInclude(rp => rp.Permission)
                      .FirstOrDefaultAsync();


            var permissionList = user?.UserRoles
                                 .SelectMany(ur => ur.Role.RolePermissions)
                                  .Where(x => x.PermissionId != null)
                                 .Select(rp => rp.Permission.Name)
                                 .Distinct()
                                 .ToList();

            if (requirement.RequiredPermissions.Any(p => permissionList.Contains(p)))
            {
                context.Succeed(requirement);
            }
        }
    }
}
