﻿using Azure.Core;
using Microsoft.Data.SqlClient;

namespace AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddCommonAuthorizationService(this IServiceCollection services, IConfiguration configuration)
        {
            var mySecretValue = KeyVaultHelper.GetSecretValue(configuration);

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                options.RequireHttpsMetadata = true; // It ensures that the JWT metadata endpoint is served over HTTPS
                options.SaveToken = true; // Saves the JWT token to the authentication properties.
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true, // Validates the Issuer of the JWT.
                    ValidateAudience = true, // Validates the Audience of the JWT.
                    ValidateLifetime = true, // Ensures the JWT hasn't expired.
                    ValidateIssuerSigningKey = true, // Validates the signing key used to create the token.
                    ValidIssuer = configuration["IdentitySettings:Issuer"], // The expected Issuer for the JWT.
                    ValidAudience = configuration["IdentitySettings:Audience"],// The expected Audience for the JWT.
                    IssuerSigningKey = new SymmetricSecurityKey(
                        Encoding.UTF8.GetBytes(mySecretValue)), // The key to validate the JWT signature.
                    ClockSkew = TimeSpan.FromSeconds(30) // Tolerance for expiration time.
                };
            });
            services.AddAuthorization(options =>
            {
                options.DefaultPolicy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .Build();
            });
            //services.AddDbContext<GlobalDatabaseReadOnlyContext>((sp, options) =>
            //{
            //    // Get the client ID of the user-assigned managed identity from appsettings
            //    var sqlGlobalClientId = configuration["AzureManagedIdentity:SQLGlobalMIClientId"];
            //    var azureSqlScope = configuration["ConnectionStrings:AzureSqlScope"];

            //    // Use ManagedIdentityCredential with the specified client ID
            //    var credential = new ManagedIdentityCredential(sqlGlobalClientId);

            //    var token = credential
            //        .GetToken(new TokenRequestContext(new[] { azureSqlScope }), CancellationToken.None);

            //    // Create SQL connection with access token
            //    var connection = new SqlConnection(configuration.GetConnectionString("GlobalConnectionString"))
            //    {
            //        AccessToken = token.Token
            //    };

            //    options.UseSqlServer(connection);
            //    options.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
            //});

            services.AddDbContext<GlobalDatabaseReadOnlyContext>(options =>
    options.UseSqlServer(configuration.GetConnectionString("GlobalConnectionString")).UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking));

            services.AddScoped<IAuthorizationHandler, PermissionHandler>();
            services.AddSingleton<IAuthorizationPolicyProvider, DynamicPermissionPolicyProvider>();
            services.AddScoped<IEntraTokenValidator, EntraTokenValidator>();
            return services;
        }
    }
}
