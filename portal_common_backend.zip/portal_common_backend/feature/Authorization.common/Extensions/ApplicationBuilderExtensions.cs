﻿namespace AA.PS.FS.Platform.Portal.Utilities.Authorization.common.Extensions
{
    public static class ApplicationBuilderExtensions
    {
        public static IApplicationBuilder UseAuthorizationMiddlewares(this IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseHttpsRedirection();
            app.UseAuthentication();
            app.UseAuthorization();

            if (env.IsDevelopment())
            {
                app.UseMiddleware<SwaggerAuthMiddleware>();
            }

            return app;
        }
    }
}
