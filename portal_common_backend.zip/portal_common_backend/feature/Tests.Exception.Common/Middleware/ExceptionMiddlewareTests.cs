﻿using AA.PS.FS.Platform.Portal.Utilities.Exception.Common.Models;
using AA.PS.FS.Platform.Portal.Utilities.Logging.Common.Application.Interfaces;


namespace Tests.Exception.Common.Middlewares
{
    public class ExceptionMiddlewareTests
    {
        private readonly ILoggingService _fakeLogger;
        private readonly ExceptionMiddleware _middleware;
        private readonly DefaultHttpContext _httpContext;

        public ExceptionMiddlewareTests()
        {
            _fakeLogger = A.Fake<ILoggingService>();
            _middleware = new ExceptionMiddleware(_fakeLogger);
            _httpContext = new DefaultHttpContext();
            _httpContext.Response.Body = new MemoryStream();
        }

        [Fact]
        public async Task InvokeAsync_WhenNoException_Should_Call_NextDelegate()
        {
            var wasCalled = false;
            RequestDelegate next = context =>
            {
                wasCalled = true;
                return Task.CompletedTask;
            };

            await _middleware.InvokeAsync(_httpContext, next);

            wasCalled.Should().BeTrue();
        }

        [Theory]
        [InlineData(typeof(UnauthorizedAccessException), 401, "Unauthorized Access")]
        [InlineData(typeof(ArgumentException), 400, "Bad Request. Invalid argument.")]
        [InlineData(typeof(KeyNotFoundException), 404, "Resource not found")]
        [InlineData(typeof(System.Exception), 500, "Internal server error")]
        public async Task InvokeAsync_WhenExceptionThrown_Should_Return_Correct_Response(Type exceptionType, int expectedStatusCode, string expectedMessage)
        {
            var exception = (System.Exception)Activator.CreateInstance(exceptionType)!;
            RequestDelegate next = context => throw exception;

            await _middleware.InvokeAsync(_httpContext, next);

            _httpContext.Response.StatusCode.Should().Be(expectedStatusCode);
            _httpContext.Response.ContentType.Should().Be("application/json");

            _httpContext.Response.Body.Seek(0, SeekOrigin.Begin);
            var body = await new StreamReader(_httpContext.Response.Body).ReadToEndAsync();
            var deserialized = JsonSerializer.Deserialize<ErrorDetails>(body);

            deserialized.Should().NotBeNull();
            deserialized!.StatusCode.Should().Be(expectedStatusCode);
            deserialized.Message.Should().Be(expectedMessage);

            A.CallTo(() => _fakeLogger.LogError(
    A<string>.That.Contains("An unhandled exception occurred"),
    A<System.Exception>.That.Matches(e => e.GetType() == exceptionType)))
    .MustHaveHappened();
        }
    }
}
