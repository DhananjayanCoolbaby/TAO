﻿using AA.PS.FS.Platform.Portal.Utilities.Exception.Common.Models;

namespace Tests.Exception.Common.Helper
{

    public class ErrorDetailsTests
    {
        [Fact]
        public void ErrorDetails_Should_Assign_Properties_Correctly()
        {
            var details = new ErrorDetails { StatusCode = 404, Message = "Not Found" };

            details.StatusCode.Should().Be(404);
            details.Message.Should().Be("Not Found");
        }
    }
}
