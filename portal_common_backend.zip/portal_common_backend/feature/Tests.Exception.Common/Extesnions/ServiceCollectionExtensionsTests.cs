﻿using AA.PS.FS.Platform.Portal.Utilities.Exception.Common.Extensions;
using AA.PS.FS.Platform.Portal.Utilities.Logging.Common.Application.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace Tests.Exception.Common.Extensions
{
    public class ServiceCollectionExtensionsTests
    {
        [Fact]
        public void AddExceptionService_Should_Register_ExceptionMiddleware()
        {
            var services = new ServiceCollection();

            var fakeLogger = A.Fake<ILoggingService>();
            services.AddSingleton(fakeLogger); 

            services.AddExceptionService();   

            var provider = services.BuildServiceProvider();
            var middleware = provider.GetService<ExceptionMiddleware>();

            middleware.Should().NotBeNull();
        }
    }
}
