﻿using AA.PS.FS.Platform.Portal.Utilities.Exception.Common.Extensions;
using Microsoft.AspNetCore.Builder;

namespace Tests.Exception.Common
{
    public class ApplicationBuilderExtensionsTests
    {
        [Fact]
        public void UseExceptionHandling_Should_Add_ExceptionMiddleware()
        {
            var middlewareAdded = false;
            var appBuilder = A.Fake<IApplicationBuilder>();

            A.CallTo(() => appBuilder.Use(A<Func<RequestDelegate, RequestDelegate>>._))
                .Invokes((Func<RequestDelegate, RequestDelegate> middleware) =>
                {
                    middlewareAdded = true;
                })
                .Returns(appBuilder);

            var result = appBuilder.UseExceptionHandling();

            result.Should().Be(appBuilder);
            middlewareAdded.Should().BeTrue();
        }
    }
}
