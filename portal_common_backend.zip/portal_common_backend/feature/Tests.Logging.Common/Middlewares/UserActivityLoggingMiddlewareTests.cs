﻿
namespace Tests.Logging.Common.Middlewares
{
    public class UserActivityLoggingMiddlewareTests
    {
        private readonly RequestDelegate _next;
        private readonly ILoggingService _fakeLogger;
        private readonly UserActivityLoggingMiddleware _middleware;

        public UserActivityLoggingMiddlewareTests()
        {
            _next = A.Fake<RequestDelegate>();
            _fakeLogger = A.Fake<ILoggingService>();
            _middleware = new UserActivityLoggingMiddleware(_next, _fakeLogger);
        }

        [Fact]
        public async Task InvokeAsync_Should_Log_User_Activity_When_Request_Path_Is_Not_Root_Or_Swagger()
        {
            var context = new DefaultHttpContext();

            var identity = new ClaimsIdentity(new[]
            {
        new Claim(ClaimTypes.NameIdentifier, "TestUser") 
    }, "Test"); 
            var user = new ClaimsPrincipal(identity);

            context.User = user; 
            context.Request.Path = "/testpath";
            context.Request.Method = "GET";

           
            await _middleware.InvokeAsync(context);

            
            A.CallTo(() => _fakeLogger.LogInformation(A<string>.That.Contains("User: TestUser")))  // Check if "TestUser" is logged
                .MustHaveHappened();
            A.CallTo(() => _fakeLogger.LogInformation(A<string>.That.Contains("Method: GET")))        // Check if "GET" method is logged
                .MustHaveHappened();
            A.CallTo(() => _fakeLogger.LogInformation(A<string>.That.Contains("Path: /testpath")))    // Check if path is logged
                .MustHaveHappened();
            A.CallTo(() => _fakeLogger.LogInformation(A<string>.That.Contains("Time: ")))             // Check if time is logged
                .MustHaveHappened();
        }

        [Fact]
        public async Task InvokeAsync_Should_Skip_Logging_For_Root_Path()
        {
            
            var context = new DefaultHttpContext();
            var user = new ClaimsPrincipal(new ClaimsIdentity(new[] { new Claim(ClaimTypes.NameIdentifier, "TestUser") }));
            context.User = user;
            context.Request.Path = "/";
            context.Request.Method = "GET";

           
            await _middleware.InvokeAsync(context);

            
            A.CallTo(() => _fakeLogger.LogInformation(A<string>._)).MustNotHaveHappened();
        }

        [Fact]
        public async Task InvokeAsync_Should_Skip_Logging_For_Swagger_Path()
        {
         
            var context = new DefaultHttpContext();
            var user = new ClaimsPrincipal(new ClaimsIdentity(new[] { new Claim(ClaimTypes.NameIdentifier, "TestUser") }));
            context.User = user;
            context.Request.Path = "/swagger";
            context.Request.Method = "GET";

            await _middleware.InvokeAsync(context);

            A.CallTo(() => _fakeLogger.LogInformation(A<string>._)).MustNotHaveHappened();
        }

        [Fact]
        public async Task InvokeAsync_Should_Log_Anonymous_User_When_No_Authentication()
        {

            var context = new DefaultHttpContext();
            context.User = new ClaimsPrincipal(new ClaimsIdentity());
            context.Request.Path = "/testpath";
            context.Request.Method = "GET";

            await _middleware.InvokeAsync(context);

            A.CallTo(() => _fakeLogger.LogInformation(A<string>.That.Contains("User: Anonymous")))
                .MustHaveHappened();
        }
    }
}