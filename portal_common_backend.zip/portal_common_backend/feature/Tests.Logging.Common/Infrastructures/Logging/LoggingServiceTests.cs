﻿
namespace Tests.Logging.Common.Infrastructure.Logging
{
    public class LoggingServiceTests
    {
        private readonly ILogger<LoggingService> _fakeLogger;
        private readonly LoggingService _loggingService;

        public LoggingServiceTests()
        {
            _fakeLogger = A.Fake<ILogger<LoggingService>>();
            _loggingService = new LoggingService(_fakeLogger);
        }

        [Fact]
        public void LogInformation_Should_Call_Logger_LogInformation()
        {
            
            var message = "Info message";

            
            _loggingService.LogInformation(message);

            
            A.CallTo(_fakeLogger).Where(call =>
         call.Method.Name == nameof(_fakeLogger.Log) &&
         call.GetArgument<LogLevel>(0) == LogLevel.Information)
         .MustHaveHappened();
        }

        [Fact]
        public void LogWarning_Should_Call_Logger_LogWarning()
        {
            
            var message = "Warning message";

            _loggingService.LogWarning(message);

            A.CallTo(_fakeLogger).Where(call =>
         call.Method.Name == nameof(_fakeLogger.Log) &&
         call.GetArgument<LogLevel>(0) == LogLevel.Warning)
         .MustHaveHappened();
        }

        [Fact]
        public void LogError_Should_Call_Logger_LogError_With_Exception()
        {
            
            var exception = new InvalidOperationException("Invalid op");
            string message = "Error occurred";

            _loggingService.LogError(message, exception);

            A.CallTo(_fakeLogger).Where(call =>
        call.Method.Name == nameof(_fakeLogger.Log) &&
        call.GetArgument<LogLevel>(0) == LogLevel.Error &&
        call.GetArgument<Exception>(3) == exception &&
        (call.GetArgument<object>(2) != null && call.GetArgument<object>(2).ToString().Contains(message)))
        .MustHaveHappened();

        }

    }
}
