﻿
namespace Tests.Logging.Common.ServiceCollection
{
    public class ServiceCollectionExtensionsTests
    {
        [Fact]
        public void AddLoggingService_Should_Register_ILoggingService_And_Serilog()
        {
            var services = new Microsoft.Extensions.DependencyInjection.ServiceCollection();
            var inMemoryConfig = new ConfigurationBuilder()
                .AddInMemoryCollection()
                .Build();
            var result = services.AddLoggingService(inMemoryConfig);
            result.Should().BeSameAs(services);

            var descriptor = services.FirstOrDefault(s => s.ServiceType == typeof(ILoggingService));
            descriptor.Should().NotBeNull();
            descriptor!.ImplementationType.Should().Be(typeof(LoggingService));
        }
    }
}
